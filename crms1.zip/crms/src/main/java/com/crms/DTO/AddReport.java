package com.crms.DTO;

import java.sql.Date;
import java.sql.Time;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class AddReport {
	private long reportId;
	private long incidentId;
	private long userId;
	private String officialName;
	private String officialDesignation;
	private Date reportDate;
	private Time reportTime;
	private String reportStation;
	private String reportDescription;
	private String reportEvidence;

}
