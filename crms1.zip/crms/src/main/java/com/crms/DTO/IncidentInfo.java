package com.crms.DTO;

import java.sql.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class IncidentInfo {
	private long incidentId;
	private long userId;
	private Date incidentDate;
	private String incidentTime;
	private String incidentType;
	private String incidentDescription;
	private String incidentLocation;

}
