package com.crms.DTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

public class SystemResponse {
	private String responseCode;
	private String responseMessage;
	private UserInfo userInfo;
	public ForgetPasswordRequest getData() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public Object getStatus() {
		// TODO Auto-generated method stub
		return null;
	}

}
