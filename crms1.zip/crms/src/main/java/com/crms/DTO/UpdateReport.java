package com.crms.DTO;

import java.sql.Date;
import java.sql.Time;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor

public class UpdateReport {
	private long updateId;
	private long incidentId;
	private Date updateDate;
	private Time updateTime;
	private String updateRemark;

}
