package com.crms.Service;

import com.crms.DTO.EmailDetails;

public interface EmailService {
	void sendEmailAlert(EmailDetails emailDetails);
}
