package com.crms.Service;

import com.crms.DTO.SystemResponse;
import com.crms.DTO.IncidentInfo;
import com.crms.DTO.LoginRequest;

import java.util.List;

import com.crms.DTO.AddIncident;
import com.crms.DTO.ForgetPasswordRequest;
import com.crms.DTO.UserRequest;
import com.crms.Model.Updates;
import com.crms.Model.Reports;
import com.crms.Model.Incidents;
import com.crms.Model.Users;

public interface UsersService {
	// For creating Account
	public SystemResponse createAccount(UserRequest userRequest);
		
		// For checking Incident details
	
	List<Incidents> incidentInfoList(IncidentInfo incidentInfo);
	
	// To create an Incident
	public Incidents addingIncidents(AddIncident addIncident);
		
		// To view report details
			// For Sending Password Through Email.
	public SystemResponse forgetPassword(ForgetPasswordRequest forgetPasswordRequest);
		
		// For Login Request
	public Users homeLoginData(LoginRequest loginRequest);

	public List<Reports> getAllReports();

	public Reports getReportById(long reportId);
	public List<Updates> getAllUpdates();

	public Updates getUpdateById(long updateId);

	public Reports searchReportById(long reportId);

	public Updates searchUpdateById(long updateId);


}
