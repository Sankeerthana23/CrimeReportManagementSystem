package com.crms.Service;

import com.crms.DTO.AddReport;
import com.crms.DTO.SystemResponse;
import com.crms.DTO.UpdateReport;

public interface AdminService {
	public SystemResponse addingReport(AddReport addReport);
    public SystemResponse updatingReport(UpdateReport updateReport);
}
