package com.crms.Model;
import java.sql.Date;
import java.sql.Time;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "updates")
public class Updates {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long updateId;
	private long incidentId;
	private Date updateDate;
	private Time updateTime;
	private String updateRemark;

}
