package com.crms.Model;
import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "incidents")
public class Incidents {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long incidentId;
	private long userId;
	private Date incidentDate;
	private String incidentTime;
	private String incidentType;
	private String incidentDescription;
	private String incidentLocation;

}
