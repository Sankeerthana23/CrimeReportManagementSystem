package com.crms.ServiceImplementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crms.DTO.AddReport;
import com.crms.DTO.SystemResponse;
import com.crms.DTO.UpdateReport;
import com.crms.Model.Reports;
import com.crms.Model.Updates;
import com.crms.Repository.ReportsRepository;
import com.crms.Repository.UpdatesRepository;

@Service
public class AdminServiceImplementation {
	@Autowired
	ReportsRepository reportsRepository;
	
	public SystemResponse addingReport(AddReport addReport) 
	{
        // Add The Report to the database;
		
		Reports reports = Reports.builder()
				.incidentId(addReport.getIncidentId())
				.userId(addReport.getUserId())
				.officialName(addReport.getOfficialName())
				.officialDesignation(addReport.getOfficialDesignation())
				.reportDate(addReport.getReportDate())
				.reportTime(addReport.getReportTime())
				.reportStation(addReport.getReportStation())
				.reportDescription(addReport.getReportDescription())
				.reportEvidence(addReport.getReportEvidence())
				.build();
		 
		reportsRepository.save(reports);
		
		return SystemResponse.builder()
				.responseCode("141")
				.responseMessage("!! Report Has Been Added/Created To The Database !!")
				.build();
	}
	
	@Autowired
	UpdatesRepository updatesRepository;
	
	public SystemResponse updatingReport(UpdateReport updateReport) 
	{
        // Add The Report to the database;
		
		Updates updates = Updates.builder()
				.incidentId(updateReport.getIncidentId())
				.updateDate(updateReport.getUpdateDate())
				.updateTime(updateReport.getUpdateTime())
				.updateRemark(updateReport.getUpdateRemark())
				.build();
		 
		updatesRepository.save(updates);
		return SystemResponse.builder()
				.responseCode("144")
				.responseMessage("!! Update has been initiated in the Database !!")
				.build();
	}

}

