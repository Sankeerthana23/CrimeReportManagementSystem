package com.crms.ServiceImplementation;
import com.crms.DTO.SystemResponse;
import com.crms.DTO.IncidentInfo;
import com.crms.DTO.UserInfo;
import com.crms.DTO.LoginRequest;
import com.crms.DTO.AddIncident;
import com.crms.DTO.ForgetPasswordRequest;
import com.crms.DTO.UserRequest;
import com.crms.Model.Updates;
import com.crms.Model.Reports;
import com.crms.Model.Incidents;
import com.crms.Model.Users;
import com.crms.Repository.UsersRepository;
import com.crms.Service.UsersService;
import com.crms.Repository.IncidentsRepository;
import com.crms.Repository.ReportsRepository;
import com.crms.Repository.UpdatesRepository;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class UsersServiceImplementation implements UsersService {
   
    @Autowired
    private IncidentsRepository incidentsRepository;
    @Autowired
    private ReportsRepository reportsRepository;
    @Autowired
    private UpdatesRepository updatesRepository;

    public UsersServiceImplementation(UsersRepository usersRepository2, IncidentsRepository incidentsRepository2,
			ReportsRepository reportsRepository2, UpdatesRepository updatesRepository2) {
				this.usersRepository = null;
		// TODO Auto-generated constructor stub
	}
    private final UsersRepository usersRepository;

    @Autowired
    public UsersServiceImplementation(UsersRepository usersRepository) {
        this.usersRepository = usersRepository;
    }
	// For creating Account
	public SystemResponse createAccount(UserRequest userRequest) {
        // Check if the userRequest is valid
        if (userRequest == null || userRequest.getEmail() == null || userRequest.getPassword() == null) {
            return new SystemResponse("400", "Invalid user request", null);
        }
        // Check if the email already exists in the database
        Optional<Users> existingUser = usersRepository.findUsersByEmail(userRequest.getEmail());
        if (existingUser.isPresent()) {
            return new SystemResponse("409", "Email already registered", null);
        }
        // Create a new user object with the userRequest data
        Users newUser = new Users();
        newUser.setName(userRequest.getName());
        newUser.setGender(userRequest.getGender());
        newUser.setAddress(userRequest.getAddress());
        newUser.setPhone(userRequest.getPhone());
        newUser.setEmail(userRequest.getEmail());
        newUser.setPassword(userRequest.getPassword());
        // Save the new user to the database
        usersRepository.save(newUser);
        // Create a new userInfo object with the user's details
        UserInfo userInfo = new UserInfo();
        userInfo.setName(newUser.getName());
        userInfo.setGender(newUser.getGender());
        userInfo.setAddress(newUser.getAddress());
        userInfo.setPhone(newUser.getPhone());
        userInfo.setEmail(newUser.getEmail());
        // Return a success message with the userInfo
        return new SystemResponse("200", "User account created successfully", userInfo);
    }
    // For checking Incident details
    @Override
    public List<Incidents> incidentInfoList(IncidentInfo incidentInfo) {
        // Check if the incidentInfo is valid
    				return incidentsRepository.listAllIncidents(incidentInfo.getIncidentId(),
						incidentInfo.getUserId(),
						incidentInfo.getIncidentDate(), 
						incidentInfo.getIncidentTime(),
						incidentInfo.getIncidentType(),
						incidentInfo.getIncidentDescription(),
						incidentInfo.getIncidentLocation());		
    }

    // To create an Incident
    public Incidents addingIncidents(AddIncident addIncident) {
        // Check if the addIncident is valid
        if (addIncident == null || addIncident.getUserId() == 0 || addIncident.getIncidentType() == null) {
            return null;
        }
        // Create a new incident object with the addIncident data
        Incidents newIncident = new Incidents();
        newIncident.setIncidentId(addIncident.getIncidentId());
        newIncident.setUserId(addIncident.getUserId());
        newIncident.setIncidentDate(addIncident.getIncidentDate());
        newIncident.setIncidentTime(addIncident.getIncidentTime());
        newIncident.setIncidentType(addIncident.getIncidentType());
        newIncident.setIncidentDescription(addIncident.getIncidentDescription());
        newIncident.setIncidentLocation(addIncident.getIncidentLocation());
        // Save the new incident to the database
        incidentsRepository.save(newIncident);
        // Return the new incident object
        return newIncident;
    }
    // To view report details
    public List<Reports> getAllReports(){
        return reportsRepository.findAll();
    }

    public Reports getReportById(long reportId) {
        return reportsRepository.findById(reportId).orElse(null);
    }
    public Reports searchReportById(long reportId) { 
    	return reportsRepository.findById(reportId).orElse(null);
    }

   
	// To view updates
    public List<Updates> getAllUpdates(){
        return updatesRepository.findAll();
    }

    public Updates getUpdateById(long updateId) {
        return updatesRepository.findById(updateId).orElse(null);
    }
    public Updates searchUpdateById(long updateId) { 
    	return updatesRepository.findById(updateId).orElse(null);
    }
    // For Sending Password Through Email.
    public SystemResponse forgetPassword(ForgetPasswordRequest forgetPasswordRequest) {
        // Check if the forgetPasswordRequest is valid
        if (forgetPasswordRequest == null || forgetPasswordRequest.getUserId() == 0 || forgetPasswordRequest.getEmail() == null) {
            return new SystemResponse("400", "Invalid forget password request", null);
        }
        // Find the user by the given user id from the database
        Optional<Users> user = usersRepository.findById(forgetPasswordRequest.getUserId());
        if (user.isEmpty()) {
            return new SystemResponse("404", "User not found", null);
        }
        // Send the password to the user's email (implementation details omitted)
        // For example, you can use an email service to send the password
        String newPassword = generateRandomPassword(); // Generate a new password
        sendPasswordByEmail(user.get().getEmail(), newPassword); // Send the password via email
        // Return a success message
        return new SystemResponse("200", "Password sent successfully", null);
    }

    // Example method to generate a random password
    private String generateRandomPassword() {
        // Implementation details omitted
        return "randomPassword123";
    }
    // Example method to send the password via email
    private void sendPasswordByEmail(String email, String password) {
        // Implementation details omitted
        // You can use an email library or service to send the email
    }
    // For Login Request
    public Users homeLoginData(LoginRequest loginRequest) {
        
        boolean isUserExists = usersRepository.existsByEmail(loginRequest.getEmail());
        
        if(!isUserExists)
        {
        	return null;
        }
        
        Users user = usersRepository.findByEmail(loginRequest.getEmail());
        
        if(!user.getPassword().equals(loginRequest.getPassword()))
        {
        	return null;
        }
        
        return user;
    }
		
}
