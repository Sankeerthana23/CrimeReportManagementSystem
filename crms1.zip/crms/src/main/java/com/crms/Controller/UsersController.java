package com.crms.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.crms.DTO.SystemResponse;
import com.crms.DTO.IncidentInfo;
import com.crms.DTO.LoginRequest;
import com.crms.DTO.AddIncident;
import com.crms.DTO.ForgetPasswordRequest;
import com.crms.DTO.UserRequest;
import com.crms.Model.Updates;
import com.crms.Model.Reports;
import com.crms.Model.Incidents;
import com.crms.Model.Users;
import com.crms.Repository.IncidentsRepository;
import com.crms.Repository.ReportsRepository;
import com.crms.Repository.UsersRepository;
import com.crms.Service.EmailService;
import com.crms.Service.UsersService;
@RestController
@RequestMapping(method = RequestMethod.GET)
public class UsersController {

	@Autowired
	UsersService usersService;
	@Autowired
	UsersRepository usersRepository;
	@Autowired
	ReportsRepository reportsRepository;
	
	// Main Landing Page;
		@PostMapping("/crms")
		public ModelAndView crms()
		{
			return new ModelAndView("main");
		}
		
		// Landing Page for createAccount;
		@PostMapping("/create")
		public ModelAndView createAccount()
		{
			return new ModelAndView("createAccount");
		}
	
	@PostMapping("/createAccount")
	public ModelAndView createAccount(UserRequest userRequest) 
	{
		SystemResponse systemResponse = usersService.createAccount(userRequest);
		ModelAndView modelAndView = new ModelAndView("createAccount");
		modelAndView.addObject("systemResponse", systemResponse);
		return modelAndView;
	}
	
	// Controller for forgetPassword after getting request from the user it will perform its task;
	@Autowired
	EmailService emailService;
	@PostMapping("/forgetPassword")
	public ModelAndView forgetPassword()
	{
		return new ModelAndView("forgetPassword");
	}
	
	// Controller for forgetPassword after getting request from the user it will perform its task;
	@GetMapping("/forgetPass")
	public ModelAndView forgetPassword(ForgetPasswordRequest forgetPasswordRequest)
	{
		SystemResponse systemResponse =  usersService.forgetPassword(forgetPasswordRequest);
		
		if(systemResponse.getUserInfo()== null)
		{
			ModelAndView mv = new ModelAndView("forgetPassword");
			mv.addObject("response" , systemResponse);
			return mv;			
		}
		
		ModelAndView mv = new ModelAndView("main");
		mv.addObject("response" , systemResponse);
		return mv;
	}

	@GetMapping("/homeWindow")
	public ModelAndView home(LoginRequest loginRequest)
	{
		Users user = usersService.homeLoginData(loginRequest);
		
		if(user==null)
		{
			ModelAndView mv = new ModelAndView("main");
			mv.addObject("message", "Invalid Details");
			return mv;
		}
		
		ModelAndView mv = new ModelAndView("home");
		mv.addObject("users" , user);
		return mv;
	}
	
	@GetMapping("/incidents")
	public ModelAndView incidentInfoList(IncidentInfo incidentInfo) {
        Optional<Users> users =  usersRepository.findById(incidentInfo.getIncidentId());
		
		List<Incidents> incidentInfoList =  usersService.incidentInfoList(incidentInfo);
		
		System.out.println(incidentInfoList);
		
		ModelAndView mv = new ModelAndView();
		mv.addObject("users", users);
		mv.addObject("history", incidentInfoList);
		return mv;
	}
	@Autowired
    private IncidentsRepository incidentsRepository;
	
	@GetMapping("/addingIncidents")
    public ModelAndView showAddingIncidentsForm(AddIncident addIncident) {
        // Create a new AddIncident object and add it to the ModelAndView object
        ModelAndView mav = new ModelAndView("addingIncidents");
        mav.addObject("addIncident", new AddIncident());
        // Return the ModelAndView object
        return mav;
    }

    // Handle the POST request for the addingIncidents form
    @PostMapping("/addingIncidents")
    public ModelAndView processAddingIncidentsForm(AddIncident addIncident) {
        // Call the service method to add a new incident
        Incidents newIncident = addingIncidents(addIncident);
        // Check if the new incident is null
        if (newIncident == null) {
            // Add an error message to the ModelAndView object and return the same JSP page
            ModelAndView mav = new ModelAndView("addingIncidents");
            mav.addObject("message", "Invalid input. Please try again.");
            return mav;
        } else {
            // Add a success message and the new incident to the ModelAndView object and return the incidentDetails JSP page
            ModelAndView mav = new ModelAndView("addingIncidents");
            mav.addObject("message", "Incident added successfully.");
            mav.addObject("newIncident", newIncident);
            return mav;
        }
    }

    // Service method to add a new incident
    public Incidents addingIncidents(AddIncident addIncident) {
        // Check if the addIncident is valid
        if (addIncident == null || addIncident.getUserId() == 0 || addIncident.getIncidentType() == null) {
            return null;
        }
        // Create a new incident object with the addIncident data
        Incidents newIncident = new Incidents();
        newIncident.setIncidentId(addIncident.getIncidentId());
        newIncident.setUserId(addIncident.getUserId());
        newIncident.setIncidentDate(addIncident.getIncidentDate());
        newIncident.setIncidentTime(addIncident.getIncidentTime());
        newIncident.setIncidentType(addIncident.getIncidentType());
        newIncident.setIncidentDescription(addIncident.getIncidentDescription());
        newIncident.setIncidentLocation(addIncident.getIncidentLocation());
        // Save the new incident to the database
        incidentsRepository.save(newIncident);
        // Return the new incident object
        return newIncident;
    }
	
	    @GetMapping("/reports")
	    public ModelAndView getAllReports() {
	        List<Reports> reports = usersService.getAllReports();
	        ModelAndView modelAndView = new ModelAndView("reports");
	        modelAndView.addObject("reports", reports);
	        return modelAndView;
	    }

	    @GetMapping("/reports/{reportId}")
	    public ModelAndView getReportById(@PathVariable long reportId) {
	        Reports report = usersService.getReportById(reportId);
	        ModelAndView modelAndView = new ModelAndView("report");
	        modelAndView.addObject("report", report);
	        return modelAndView;
	    }
	    
	    @GetMapping("/searchReport") public ModelAndView searchReport(@RequestParam("reportId") long reportId) { 
	    	Reports report = usersService.searchReportById(reportId);
	    	ModelAndView modelAndView = new ModelAndView("report"); 
	    	modelAndView.addObject("report", report); 
	    	return modelAndView; 
	    }
	
	
	    @GetMapping("/updates")
	    public ModelAndView getAllUpdates() {
	        List<Updates> updates = usersService.getAllUpdates();
	        ModelAndView modelAndView = new ModelAndView("updates");
	        modelAndView.addObject("updates", updates);
	        return modelAndView;
	    }

	    @GetMapping("/updates/{updateId}")
	    public ModelAndView getUpdateById(@PathVariable long updateId) {
	    	Updates update = usersService.getUpdateById(updateId);
	        ModelAndView modelAndView = new ModelAndView("update");
	        modelAndView.addObject("update", update);
	        return modelAndView;
	    }
	    @GetMapping("/searchUpdate") public ModelAndView searchUpdate(@RequestParam("updateId") long updateId) { 
	    	Updates update= usersService.searchUpdateById(updateId);
	    	ModelAndView modelAndView = new ModelAndView("update"); 
	    	modelAndView.addObject("update", update); 
	    	return modelAndView; 
	    }
	    
	@GetMapping("/logout")
	public ModelAndView logout() 
	{
		ModelAndView mv = new ModelAndView("main");
		mv.addObject("message", "!! You hava SUCCESSFULLY LOGOUT !!");
		return mv;
	}
}

