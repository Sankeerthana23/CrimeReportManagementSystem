package com.crms.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.crms.DTO.AddReport;
import com.crms.DTO.SystemResponse;
import com.crms.DTO.UpdateReport;
import com.crms.ServiceImplementation.AdminServiceImplementation;
@RestController
@RequestMapping(method = RequestMethod.GET)
public class AdminController {

	@Autowired
	AdminServiceImplementation adminServiceImplementation;
	
	@PostMapping("/addReport")
	public ModelAndView addReport(@RequestBody AddReport addReport) {
		SystemResponse systemResponse = adminServiceImplementation.addingReport(addReport);
		ModelAndView modelAndView = new ModelAndView("reportView");
		modelAndView.addObject("systemResponse", systemResponse);
		return modelAndView;
	}
	
	@PostMapping("/updateReport")
	public ModelAndView updateReport(@RequestBody UpdateReport updateReport) {
		SystemResponse systemResponse = adminServiceImplementation.updatingReport(updateReport);
		ModelAndView modelAndView = new ModelAndView("updateView");
		modelAndView.addObject("systemResponse", systemResponse);
		return modelAndView;
	}
}

