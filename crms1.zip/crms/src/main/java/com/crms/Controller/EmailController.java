package com.crms.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.crms.DTO.EmailDetails;
import com.crms.Service.EmailService;
@RestController

public class EmailController {

	@Autowired
	EmailService emailService;
	
	@PostMapping("/sendEmail")
	public ModelAndView sendEmail(@RequestBody EmailDetails emailDetails) {
		emailService.sendEmailAlert(emailDetails);
		ModelAndView modelAndView = new ModelAndView("emailView");
		modelAndView.addObject("emailDetails", emailDetails);
		return modelAndView;
	}
}
