package com.crms.Repository;
import com.crms.Model.Reports;

import java.sql.Date;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ReportsRepository extends JpaRepository<Reports, Long> {

    // Custom query methods
	Optional<Reports> findReportsByIncidentId(long incidentId);
    //Optional<Reports> findByUserId(long userId);
    Reports findReportsByOfficialName(String officialName);
    
    Optional<Reports> findReportsByReportDate(Date reportDate);
   // List<Reports> findAll(long reportId);
    
    //List<Reports> findAllByReportId(long reportId);
   // @Query("SELECT r FROM Reports r WHERE r.reportId = :reportId AND r.incidentId = :incidentId AND r.userId = :userId AND r.officialName = :officialName AND r.officialDesignation = :officialDesignation AND r.reportDate = :reportDate AND r.reportTime = :reportTime AND r.reportStation = :reportStation AND r.reportDescription = :reportDescription AND r.reportEvidence = :reportEvidence")
   // List<Reports> listAllReports(@Param("reportId") long reportId, @Param("incidentId") long incidentId, @Param("userId") long userId, @Param("officialName") String officialName, @Param("officialDesignation") String officialDesignation, @Param("reportDate") Date reportDate, @Param("reportTime") Time reportTime, @Param("reportStation") String reportStation, @Param("reportDescription") String reportDescription, @Param("reportEvidence") String reportEvidence);
}

