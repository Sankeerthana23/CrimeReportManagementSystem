package com.crms.Repository;

import com.crms.Model.Incidents;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface IncidentsRepository extends JpaRepository<Incidents, Long> {

    // Custom query methods
   
    Incidents findIncidentsByIncidentId(long incidentId);
    Optional<Incidents> findIncidentsByIncidentDate(Date incidentDate);
    Optional<Incidents> findIncidentsByIncidentType(String incidentType);
    Optional<Incidents> findIncidentsByIncidentLocation(String incidentLocation);

    // List method to get all incidents data from the database
 // List method to get incidents data from the database by an IncidentInfo object
    @Query("SELECT i FROM Incidents i WHERE i.incidentId = :incidentId AND i.userId = :userId AND i.incidentDate = :incidentDate AND i.incidentTime = :incidentTime AND i.incidentType = :incidentType AND i.incidentDescription = :incidentDescription AND i.incidentLocation = :incidentLocation")
    List<Incidents> listAllIncidents(@Param("incidentId") long incidentId, @Param("userId") long userId, @Param("incidentDate") Date incidentDate, @Param("incidentTime") String incidentTime, @Param("incidentType") String incidentType, @Param("incidentDescription") String incidentDescription, @Param("incidentLocation") String incidentLocation);

}

