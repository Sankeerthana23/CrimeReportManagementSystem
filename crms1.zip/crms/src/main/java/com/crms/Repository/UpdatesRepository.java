package com.crms.Repository;
import com.crms.Model.Updates;

import java.sql.Date;
import java.sql.Time;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UpdatesRepository extends JpaRepository<Updates, Long> {

    // Custom query methods
    Updates findUpdatesByIncidentId(long incidentId);
    Optional<Updates> findUpdatesByUpdateDate(Date updateDate);
    Optional<Updates> findUpdatesByUpdateTime(Time updateTime);
    //@Query("SELECT u FROM Updates u WHERE u.updateId =:updateId AND u.incidentId = :incidentId AND u.updateDate = :updateDate AND u.updateTime = :updateTime AND u.updateRemark = :updateRemark")
    //List<Updates> listAllUpdates(@Param("updateId") long updateId, @Param("incidentId") long incidentId, @Param("updateDate") Date updateDate, @Param("updateTime") Time updateTime, @Param("updateRemark") String updateRemark);
}

