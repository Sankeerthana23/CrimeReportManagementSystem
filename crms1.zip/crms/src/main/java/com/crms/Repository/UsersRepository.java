package com.crms.Repository;

import com.crms.DTO.UserRequest;
import com.crms.Model.Users;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UsersRepository extends JpaRepository<Users, Long> {

    // Custom query methods using Optional
    Users findUsersByName(String name);
    Optional<Users> findUsersByEmail(String email);
    Optional<Users> findUsersByGender(String gender);
	Users save(UserRequest user);
	
	
	boolean existsByEmail(String email);
	Users findByEmail(String email);
	
	
}

