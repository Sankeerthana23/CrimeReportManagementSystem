package com.crms;

import com.crms.DTO.SystemResponse;
import com.crms.DTO.UserRequest;
import com.crms.Model.Users;
import com.crms.Repository.UsersRepository;
import com.crms.ServiceImplementation.UsersServiceImplementation;

import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;

public class UsersServiceImplementationTest {

	 @Mock
	    private UsersRepository usersRepository;

	    @InjectMocks
	    private UsersServiceImplementation usersService;

	    @BeforeEach
	    public void init() {
	        MockitoAnnotations.openMocks(this);
	    }
	    @Before(value = "")
	    public void setUp() {
	        this.usersService = new UsersServiceImplementation(usersRepository);
	    }

    @Test
    public void testCreateAccount_Success() {
        String email = "johndoe@gmail.com";
        String password = "password";
        Users user = new Users();
        user.setEmail(email);
        user.setPassword(password);
        when(usersRepository.findUsersByEmail(email)).thenReturn(Optional.empty());
        when(usersRepository.save(user)).thenReturn(user);

        UserRequest userRequest = new UserRequest();
        userRequest.setEmail(email);
        userRequest.setPassword(password);
        SystemResponse response = usersService.createAccount(userRequest);

        assertEquals("200", response.getStatus());
        assertEquals("User account created successfully", response.getResponseMessage());
        assertEquals(user, response.getData());
    }

    @Test
    public void testCreateAccount_Failure_EmailExists() {
        String email = "johndoe@gmail.com";
        Users user = new Users();
        user.setEmail(email);
        when(usersRepository.findUsersByEmail(email)).thenReturn(Optional.of(user));

        UserRequest userRequest = new UserRequest();
        userRequest.setEmail(email);
        SystemResponse response = usersService.createAccount(userRequest);

        assertEquals("400", response.getStatus());
        assertEquals("Email already registered", response.getResponseMessage());
        assertEquals(null, response.getData());
    }

}